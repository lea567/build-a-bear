import React, { createContext, useContext, useReducer, useCallback } from 'react';
import { DEFAULT_CONFIG, calculatePrice } from '../data/catalog';

const BearContext = createContext(null);

const initialState = {
  config: { ...DEFAULT_CONFIG },
  audioBlob: null,
  audioUrl: null,
  savedAudioFilename: null,
  isRecording: false,
  isSaving: false,
  savedBears: [],
  cart: [],
  activeTab: 'bearType',
  rotation: 0,
};

function bearReducer(state, action) {
  switch (action.type) {
    case 'SET_CONFIG':
      return { ...state, config: { ...state.config, ...action.payload } };
    case 'SET_BEAR_COLOR':
      return { ...state, config: { ...state.config, bearColor: action.payload } };
    case 'SET_CLOTHES_COLOR':
      return { ...state, config: { ...state.config, clothesColor: action.payload } };
    case 'SET_AUDIO':
      return { ...state, audioBlob: action.blob, audioUrl: action.url };
    case 'SET_SAVED_AUDIO':
      return { ...state, savedAudioFilename: action.filename };
    case 'SET_RECORDING':
      return { ...state, isRecording: action.payload };
    case 'SET_SAVING':
      return { ...state, isSaving: action.payload };
    case 'SET_SAVED_BEARS':
      return { ...state, savedBears: action.payload };
    case 'ADD_TO_CART':
      return { ...state, cart: [...state.cart, action.payload] };
    case 'REMOVE_FROM_CART':
      return { ...state, cart: state.cart.filter(item => item.id !== action.payload) };
    case 'SET_CART':
      return { ...state, cart: action.payload };
    case 'SET_ACTIVE_TAB':
      return { ...state, activeTab: action.payload };
    case 'SET_ROTATION':
      return { ...state, rotation: action.payload };
    case 'LOAD_BEAR':
      return { ...state, config: action.payload };
    case 'RESET':
      return { ...initialState, savedBears: state.savedBears };
    default:
      return state;
  }
}

export function BearProvider({ children }) {
  const [state, dispatch] = useReducer(bearReducer, initialState);

  const setConfig = useCallback((updates) => dispatch({ type: 'SET_CONFIG', payload: updates }), []);
  const setBearColor = useCallback((color) => dispatch({ type: 'SET_BEAR_COLOR', payload: color }), []);
  const setClothesColor = useCallback((color) => dispatch({ type: 'SET_CLOTHES_COLOR', payload: color }), []);
  const setAudio = useCallback((blob, url) => dispatch({ type: 'SET_AUDIO', blob, url }), []);
  const setRecording = useCallback((val) => dispatch({ type: 'SET_RECORDING', payload: val }), []);
  const setSaving = useCallback((val) => dispatch({ type: 'SET_SAVING', payload: val }), []);
  const setSavedBears = useCallback((bears) => dispatch({ type: 'SET_SAVED_BEARS', payload: bears }), []);
  const setActiveTab = useCallback((tab) => dispatch({ type: 'SET_ACTIVE_TAB', payload: tab }), []);
  const loadBear = useCallback((config) => dispatch({ type: 'LOAD_BEAR', payload: config }), []);
  const reset = useCallback(() => dispatch({ type: 'RESET' }), []);
  const setCart = useCallback((cart) => dispatch({ type: 'SET_CART', payload: cart }), []);
  const removeFromCart = useCallback((id) => dispatch({ type: 'REMOVE_FROM_CART', payload: id }), []);
  const setSavedAudio = useCallback((filename) => dispatch({ type: 'SET_SAVED_AUDIO', filename }), []);

  const totalPrice = calculatePrice(state.config);

  return (
    <BearContext.Provider value={{
      ...state,
      totalPrice,
      setConfig,
      setBearColor,
      setClothesColor,
      setAudio,
      setRecording,
      setSaving,
      setSavedBears,
      setActiveTab,
      loadBear,
      reset,
      setCart,
      removeFromCart,
      setSavedAudio,
    }}>
      {children}
    </BearContext.Provider>
  );
}

export function useBear() {
  const ctx = useContext(BearContext);
  if (!ctx) throw new Error('useBear must be used within BearProvider');
  return ctx;
}
