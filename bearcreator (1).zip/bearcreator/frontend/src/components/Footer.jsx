import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function Footer() {
  const navigate = useNavigate();
  return (
    <footer className="footer">
      <div className="footer-wave">
        <svg viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,60 1080,0 1440,30 L1440,60 L0,60 Z" fill="#1a0a00" /></svg>
      </div>
      <div className="footer-inner">
        <div className="footer-brand">
          <span style={{ fontSize: 40 }}>🐻</span>
          <h3>BearCreator Workshop</h3>
          <p>The Stuff You Love — made by you, with love.</p>
          <div className="footer-social">
            {['📘', '📸', '🎵', '🐦'].map((s, i) => (
              <button key={i} className="social-btn">{s}</button>
            ))}
          </div>
        </div>
        <div className="footer-col">
          <h4>Shop</h4>
          <button onClick={() => navigate('/shop')}>All Bears</button>
          <button onClick={() => navigate('/shop')}>Clothing</button>
          <button onClick={() => navigate('/shop')}>Accessories</button>
          <button onClick={() => navigate('/shop')}>Gift Sets</button>
          <button onClick={() => navigate('/shop')}>Sale</button>
        </div>
        <div className="footer-col">
          <h4>Build</h4>
          <button onClick={() => navigate('/build')}>Start Building</button>
          <button onClick={() => navigate('/build')}>Bear Types</button>
          <button onClick={() => navigate('/build')}>Voice Messages</button>
          <button onClick={() => navigate('/build')}>My Saved Bears</button>
        </div>
        <div className="footer-col">
          <h4>Help</h4>
          <button>Shipping Info</button>
          <button>Returns</button>
          <button>FAQ</button>
          <button>Contact Us</button>
          <button>Store Locator</button>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© 2025 BearCreator Workshop. All bears loved.</span>
        <div className="footer-bottom-links">
          <button>Privacy Policy</button>
          <button>Terms of Service</button>
          <button>Accessibility</button>
        </div>
      </div>
    </footer>
  );
}
