import React from 'react';

// Helper to darken/lighten a hex color
function adjustColor(hex, amount) {
  const num = parseInt(hex.replace('#', ''), 16);
  const r = Math.max(0, Math.min(255, (num >> 16) + amount));
  const g = Math.max(0, Math.min(255, ((num >> 8) & 0xff) + amount));
  const b = Math.max(0, Math.min(255, (num & 0xff) + amount));
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
}

function BearBody({ color, bearType }) {
  const shadow = adjustColor(color, -40);
  const highlight = adjustColor(color, 30);
  const nose = bearType === 'panda' ? '#1A202C' : '#3D1F0D';
  const eyeColor = bearType === 'panda' ? '#1A202C' : '#2D1B00';
  const innerEarColor = bearType === 'panda' ? '#1A202C' : adjustColor(color, -20);
  const bellyColor = bearType === 'panda' ? '#F0EEE9' : adjustColor(color, 35);

  return (
    <g id="bear-body">
      {/* Drop shadow */}
      <ellipse cx="200" cy="390" rx="90" ry="18" fill="rgba(0,0,0,0.12)" />

      {/* Body */}
      <ellipse cx="200" cy="310" rx="90" ry="100" fill={color} />
      <ellipse cx="200" cy="310" rx="85" ry="95" fill={highlight} opacity="0.15" />

      {/* Belly */}
      <ellipse cx="200" cy="330" rx="50" ry="58" fill={bellyColor} opacity="0.9" />

      {/* Left leg */}
      <ellipse cx="155" cy="385" rx="32" ry="22" fill={color} />
      <ellipse cx="148" cy="394" rx="28" ry="15" fill={shadow} />

      {/* Right leg */}
      <ellipse cx="245" cy="385" rx="32" ry="22" fill={color} />
      <ellipse cx="252" cy="394" rx="28" ry="15" fill={shadow} />

      {/* Left arm */}
      <ellipse cx="120" cy="290" rx="22" ry="40" fill={color} transform="rotate(-20 120 290)" />
      <ellipse cx="113" cy="318" rx="20" ry="16" fill={shadow} transform="rotate(-20 113 318)" />

      {/* Right arm */}
      <ellipse cx="280" cy="290" rx="22" ry="40" fill={color} transform="rotate(20 280 290)" />
      <ellipse cx="287" cy="318" rx="20" ry="16" fill={shadow} transform="rotate(20 287 318)" />

      {/* Neck */}
      <ellipse cx="200" cy="228" rx="38" ry="20" fill={color} />

      {/* Head */}
      <circle cx="200" cy="175" r="88" fill={color} />
      <circle cx="200" cy="175" r="84" fill={highlight} opacity="0.12" />

      {/* Ears */}
      <circle cx="133" cy="108" r="32" fill={color} />
      <circle cx="133" cy="108" r="20" fill={innerEarColor} opacity="0.8" />
      <circle cx="267" cy="108" r="32" fill={color} />
      <circle cx="267" cy="108" r="20" fill={innerEarColor} opacity="0.8" />

      {/* Panda eye patches */}
      {bearType === 'panda' && (
        <>
          <ellipse cx="172" cy="168" rx="22" ry="20" fill="#1A202C" />
          <ellipse cx="228" cy="168" rx="22" ry="20" fill="#1A202C" />
        </>
      )}

      {/* Eyes */}
      <circle cx="172" cy="168" r="10" fill={eyeColor} />
      <circle cx="228" cy="168" r="10" fill={eyeColor} />
      <circle cx="170" cy="165" r="4" fill="white" opacity="0.9" />
      <circle cx="226" cy="165" r="4" fill="white" opacity="0.9" />
      <circle cx="171" cy="166" r="2" fill="white" opacity="0.6" />
      <circle cx="227" cy="166" r="2" fill="white" opacity="0.6" />

      {/* Snout */}
      <ellipse cx="200" cy="196" rx="30" ry="22" fill={bellyColor} />

      {/* Nose */}
      <ellipse cx="200" cy="189" rx="10" ry="7" fill={nose} />

      {/* Mouth */}
      <path d="M193 200 Q200 210 207 200" stroke={nose} strokeWidth="2.5" fill="none" strokeLinecap="round" />

      {/* Cheek blush */}
      <circle cx="152" cy="195" r="18" fill="#FBBDBD" opacity="0.45" />
      <circle cx="248" cy="195" r="18" fill="#FBBDBD" opacity="0.45" />

      {/* Belly button */}
      <circle cx="200" cy="355" r="5" fill={shadow} opacity="0.5" />
    </g>
  );
}

function ClothesLayer({ clothes, clothesColor }) {
  if (!clothes || clothes === 'none') return null;
  const color = clothesColor || clothes.color || '#E53E3E';
  const dark = adjustColor(color === 'rainbow' ? '#E53E3E' : color, -30);

  switch (clothes.style) {
    case 'tshirt':
      return (
        <g id="clothes-layer">
          <path d="M125 240 Q140 225 200 225 Q260 225 275 240 L285 310 Q200 325 115 310 Z" fill={color} />
          {/* Collar */}
          <path d="M170 225 Q200 240 230 225" stroke={dark} strokeWidth="3" fill="none" />
          {/* Sleeves */}
          <path d="M125 240 L103 275 L120 285 L138 255 Z" fill={color} />
          <path d="M275 240 L297 275 L280 285 L262 255 Z" fill={color} />
          {/* Stripe detail */}
          <path d="M130 270 Q200 285 270 270" stroke={dark} strokeWidth="2" fill="none" opacity="0.4" />
        </g>
      );

    case 'dress':
      return (
        <g id="clothes-layer">
          <path d="M140 235 Q200 220 260 235 L285 310 Q260 340 200 345 Q140 340 115 310 Z" fill={color} />
          {/* Flare */}
          <path d="M115 310 Q135 360 155 385 Q200 395 245 385 Q265 360 285 310 Q260 340 200 345 Q140 340 115 310 Z" fill={adjustColor(color, 15)} opacity="0.9" />
          {/* Waistband */}
          <path d="M130 290 Q200 305 270 290" stroke={dark} strokeWidth="4" fill="none" />
          {/* Bow on chest */}
          <path d="M185 250 L200 260 L215 250 L200 240 Z" fill={dark} opacity="0.7" />
          {/* Collar */}
          <path d="M168 235 Q200 250 232 235" stroke={dark} strokeWidth="2.5" fill="none" />
        </g>
      );

    case 'overalls':
      return (
        <g id="clothes-layer">
          {/* Pants */}
          <path d="M135 270 Q155 260 200 260 Q245 260 265 270 L275 385 Q240 390 220 385 L210 340 Q200 350 190 340 L180 385 Q160 390 125 385 Z" fill={color} />
          {/* Bib */}
          <path d="M170 240 Q200 230 230 240 L225 270 Q200 278 175 270 Z" fill={color} />
          {/* Straps */}
          <path d="M175 240 L155 270" stroke={dark} strokeWidth="8" strokeLinecap="round" />
          <path d="M225 240 L245 270" stroke={dark} strokeWidth="8" strokeLinecap="round" />
          {/* Pocket */}
          <rect x="183" y="247" width="34" height="22" rx="3" fill={dark} opacity="0.4" />
          {/* Buttons */}
          <circle cx="168" cy="270" r="4" fill={dark} opacity="0.7" />
          <circle cx="232" cy="270" r="4" fill={dark} opacity="0.7" />
        </g>
      );

    case 'hoodie':
      return (
        <g id="clothes-layer">
          <path d="M120 235 Q160 220 200 220 Q240 220 280 235 L290 320 Q200 335 110 320 Z" fill={color} />
          {/* Hood */}
          <path d="M155 220 Q200 205 245 220 Q240 235 200 238 Q160 235 155 220 Z" fill={adjustColor(color, -15)} />
          {/* Pocket */}
          <path d="M162 285 Q200 295 238 285 L235 318 Q200 325 165 318 Z" fill={dark} opacity="0.35" />
          {/* Zipper */}
          <line x1="200" y1="225" x2="200" y2="318" stroke={dark} strokeWidth="2.5" strokeDasharray="5,4" />
          {/* Sleeves */}
          <path d="M120 235 L95 280 L115 290 L137 250 Z" fill={color} />
          <path d="M280 235 L305 280 L285 290 L263 250 Z" fill={color} />
        </g>
      );

    case 'suit':
      return (
        <g id="clothes-layer">
          {/* Jacket */}
          <path d="M125 235 Q165 220 200 220 Q235 220 275 235 L282 322 Q200 335 118 322 Z" fill={color} />
          {/* Lapels */}
          <path d="M175 220 L185 270 L200 260" fill={adjustColor(color, 20)} />
          <path d="M225 220 L215 270 L200 260" fill={adjustColor(color, 20)} />
          {/* Shirt */}
          <path d="M190 220 L200 260 L210 220" fill="white" opacity="0.9" />
          {/* Tie */}
          <path d="M197 225 L200 270 L203 225 L200 222 Z" fill="#E53E3E" />
          {/* Pocket square */}
          <path d="M240 248 L252 248 L252 256 L240 256 Z" fill="white" opacity="0.8" />
          {/* Buttons */}
          <circle cx="200" cy="282" r="3.5" fill={adjustColor(color, 40)} />
          <circle cx="200" cy="296" r="3.5" fill={adjustColor(color, 40)} />
          {/* Sleeves */}
          <path d="M125 235 L102 276 L118 287 L140 248 Z" fill={color} />
          <path d="M275 235 L298 276 L282 287 L260 248 Z" fill={color} />
        </g>
      );

    default:
      return null;
  }
}

function HatLayer({ hat }) {
  if (!hat || hat === 'none') return null;
  const color = hat.color || '#F6AD55';
  const dark = adjustColor(color === '#FFFFFF' ? '#E0E0E0' : color, -40);

  switch (hat.style) {
    case 'party':
      return (
        <g id="hat-layer">
          <polygon points="200,62 162,140 238,140" fill={color} />
          <polygon points="200,62 162,140 238,140" fill="url(#partyStripe)" opacity="0.6" />
          <ellipse cx="200" cy="140" rx="38" ry="10" fill={dark} />
          <circle cx="200" cy="64" r="6" fill="#F6E05E" />
          <defs>
            <pattern id="partyStripe" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
              <line x1="0" y1="20" x2="20" y2="0" stroke="white" strokeWidth="4" opacity="0.5" />
            </pattern>
          </defs>
        </g>
      );

    case 'tophat':
      return (
        <g id="hat-layer">
          <rect x="165" y="72" width="70" height="75" rx="4" fill={color} />
          <rect x="148" y="144" width="104" height="16" rx="4" fill={color} />
          <rect x="152" y="145" width="96" height="10" rx="2" fill={adjustColor(color, 30)} opacity="0.3" />
          {/* Hatband */}
          <rect x="165" y="128" width="70" height="12" rx="2" fill={adjustColor(color, 40)} opacity="0.6" />
        </g>
      );

    case 'beanie':
      return (
        <g id="hat-layer">
          <path d="M118 148 Q130 95 200 90 Q270 95 282 148 Z" fill={color} />
          <rect x="116" y="148" width="168" height="18" rx="9" fill={dark} />
          {/* Pom pom */}
          <circle cx="200" cy="90" r="16" fill={adjustColor(color, 20)} />
          <circle cx="200" cy="88" r="10" fill="white" opacity="0.3" />
          {/* Stripes */}
          <path d="M124 130 Q200 125 276 130" stroke={adjustColor(color, 30)} strokeWidth="8" fill="none" opacity="0.5" />
          <path d="M120 112 Q200 108 280 112" stroke={adjustColor(color, 30)} strokeWidth="6" fill="none" opacity="0.4" />
        </g>
      );

    case 'bow':
      return (
        <g id="hat-layer">
          <ellipse cx="170" cy="110" rx="30" ry="18" fill={color} transform="rotate(-20 170 110)" />
          <ellipse cx="230" cy="110" rx="30" ry="18" fill={color} transform="rotate(20 230 110)" />
          <circle cx="200" cy="112" r="14" fill={dark} />
          <circle cx="200" cy="110" r="8" fill={adjustColor(color, 20)} />
        </g>
      );

    case 'cap':
      return (
        <g id="hat-layer">
          <path d="M120 148 Q140 105 200 100 Q260 105 280 148 Z" fill={color} />
          {/* Brim */}
          <path d="M112 148 Q160 160 200 158 Q180 170 130 162 Z" fill={dark} />
          {/* Button */}
          <circle cx="200" cy="102" r="8" fill={dark} />
          {/* Panels line */}
          <line x1="200" y1="104" x2="200" y2="148" stroke={dark} strokeWidth="2" opacity="0.5" />
        </g>
      );

    case 'crown':
      return (
        <g id="hat-layer">
          <path d="M155 148 L165 98 L200 118 L235 98 L245 148 Z" fill={color} />
          <rect x="155" y="145" width="90" height="16" rx="4" fill={adjustColor(color, -20)} />
          {/* Jewels */}
          <circle cx="200" cy="118" r="7" fill="#E53E3E" />
          <circle cx="170" cy="110" r="5" fill="#48BB78" />
          <circle cx="230" cy="110" r="5" fill="#4299E1" />
          <circle cx="162" cy="145" r="4" fill={adjustColor(color, 20)} />
          <circle cx="238" cy="145" r="4" fill={adjustColor(color, 20)} />
        </g>
      );

    case 'santa':
      return (
        <g id="hat-layer">
          <path d="M155 148 Q175 110 185 75 Q192 55 205 65 Q215 120 248 148 Z" fill="#E53E3E" />
          <rect x="118" y="144" width="164" height="20" rx="10" fill="white" />
          {/* Pom pom */}
          <circle cx="205" cy="65" r="14" fill="white" />
        </g>
      );

    case 'witch':
      return (
        <g id="hat-layer">
          <polygon points="200,52 158,150 242,150" fill={color} />
          <ellipse cx="200" cy="150" rx="52" ry="14" fill={dark} />
          {/* Buckle */}
          <rect x="188" y="144" width="24" height="14" rx="2" fill={adjustColor(color, 40)} opacity="0.7" />
          <rect x="192" y="147" width="16" height="8" rx="1" fill={color} />
        </g>
      );

    case 'flower_crown':
      return (
        <g id="hat-layer">
          {[130, 155, 180, 200, 220, 245, 270].map((x, i) => {
            const flowerColors = ['#F687B3', '#FBB6CE', '#F6E05E', '#68D391', '#90CDF4', '#B794F4', '#FC8181'];
            const fc = flowerColors[i % flowerColors.length];
            return (
              <g key={x}>
                {[-1, 0, 1, 2, 3, 4].map(petal => (
                  <ellipse
                    key={petal}
                    cx={x}
                    cy={118}
                    rx="6"
                    ry="10"
                    fill={fc}
                    transform={`rotate(${petal * 60} ${x} 118)`}
                    opacity="0.9"
                  />
                ))}
                <circle cx={x} cy={118} r="5" fill="#F6E05E" />
              </g>
            );
          })}
          <path d="M125 125 Q200 135 275 125" stroke="#68D391" strokeWidth="5" fill="none" />
        </g>
      );

    default:
      return null;
  }
}

function AccessoryLayer({ accessory }) {
  if (!accessory || accessory === 'none') return null;
  const color = accessory.color || '#4A5568';

  switch (accessory.style) {
    case 'glasses_round':
      return (
        <g id="accessory-layer">
          <circle cx="172" cy="170" r="20" stroke={color} strokeWidth="3.5" fill="rgba(173,216,230,0.2)" />
          <circle cx="228" cy="170" r="20" stroke={color} strokeWidth="3.5" fill="rgba(173,216,230,0.2)" />
          <line x1="192" y1="170" x2="208" y2="170" stroke={color} strokeWidth="3" />
          <line x1="152" y1="170" x2="138" y2="165" stroke={color} strokeWidth="3" strokeLinecap="round" />
          <line x1="248" y1="170" x2="262" y2="165" stroke={color} strokeWidth="3" strokeLinecap="round" />
        </g>
      );

    case 'glasses_square':
      return (
        <g id="accessory-layer">
          <rect x="153" y="155" width="38" height="28" rx="4" stroke={color} strokeWidth="3.5" fill="rgba(173,216,230,0.15)" />
          <rect x="209" y="155" width="38" height="28" rx="4" stroke={color} strokeWidth="3.5" fill="rgba(173,216,230,0.15)" />
          <line x1="191" y1="168" x2="209" y2="168" stroke={color} strokeWidth="3" />
          <line x1="153" y1="168" x2="135" y2="163" stroke={color} strokeWidth="3" strokeLinecap="round" />
          <line x1="247" y1="168" x2="265" y2="163" stroke={color} strokeWidth="3" strokeLinecap="round" />
        </g>
      );

    case 'glasses_heart':
      return (
        <g id="accessory-layer">
          <path d="M172 162 C172 158 167 155 163 158 C159 158 153 161 153 167 C153 172 172 181 172 181 C172 181 191 172 191 167 C191 161 185 158 181 158 C177 155 172 158 172 162Z" fill={color} opacity="0.8" />
          <path d="M228 162 C228 158 223 155 219 158 C215 158 209 161 209 167 C209 172 228 181 228 181 C228 181 247 172 247 167 C247 161 241 158 237 158 C233 155 228 158 228 162Z" fill={color} opacity="0.8" />
          <line x1="191" y1="167" x2="209" y2="167" stroke={color} strokeWidth="2.5" />
          <line x1="153" y1="164" x2="136" y2="159" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
          <line x1="247" y1="164" x2="264" y2="159" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
        </g>
      );

    case 'scarf':
      return (
        <g id="accessory-layer">
          {accessory.color === 'rainbow' ? (
            <>
              <defs>
                <linearGradient id="rainbowGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#E53E3E" />
                  <stop offset="20%" stopColor="#ED8936" />
                  <stop offset="40%" stopColor="#ECC94B" />
                  <stop offset="60%" stopColor="#48BB78" />
                  <stop offset="80%" stopColor="#4299E1" />
                  <stop offset="100%" stopColor="#805AD5" />
                </linearGradient>
              </defs>
              <path d="M148 232 Q200 225 252 232 Q260 242 252 248 Q200 238 148 248 Q140 242 148 232 Z" fill="url(#rainbowGrad)" />
              <path d="M148 248 Q155 265 140 285 Q132 290 130 300 L150 305 Q152 292 158 278 Q162 268 170 258 Q162 250 148 248 Z" fill="url(#rainbowGrad)" />
            </>
          ) : (
            <>
              <path d="M148 232 Q200 225 252 232 Q260 242 252 248 Q200 238 148 248 Q140 242 148 232 Z" fill={color} />
              <path d="M148 248 Q155 265 140 285 Q132 290 130 300 L150 305 Q152 292 158 278 Q162 268 170 258 Q162 250 148 248 Z" fill={color} />
              <path d="M150 256 Q162 260 170 262" stroke={adjustColor(color, 30)} strokeWidth="2" fill="none" opacity="0.6" />
            </>
          )}
        </g>
      );

    case 'bowtie':
      return (
        <g id="accessory-layer">
          <polygon points="180,232 200,240 180,248" fill={color} />
          <polygon points="220,232 200,240 220,248" fill={color} />
          <circle cx="200" cy="240" r="6" fill={adjustColor(color, -20)} />
        </g>
      );

    case 'necktie':
      return (
        <g id="accessory-layer">
          <path d="M195 225 L205 225 L210 285 L200 296 L190 285 Z" fill={color} />
          <path d="M197 225 L203 225 L200 232 Z" fill={adjustColor(color, 20)} />
          {/* Stripe */}
          <line x1="192" y1="258" x2="208" y2="262" stroke={adjustColor(color, 30)} strokeWidth="2.5" opacity="0.5" />
          <line x1="191" y1="272" x2="207" y2="276" stroke={adjustColor(color, 30)} strokeWidth="2.5" opacity="0.5" />
        </g>
      );

    case 'necklace':
      return (
        <g id="accessory-layer">
          <path d="M160 238 Q200 248 240 238" stroke={color} strokeWidth="3.5" fill="none" strokeLinecap="round" />
          {[160, 173, 186, 200, 214, 227, 240].map((x, i) => (
            <circle key={i} cx={x} cy={i % 2 === 0 ? 238 : 242} r="4.5" fill={color} />
          ))}
          {/* Pendant */}
          <ellipse cx="200" cy="252" rx="9" ry="11" fill={adjustColor(color, -20)} />
          <ellipse cx="200" cy="252" rx="5" ry="7" fill={adjustColor(color, 20)} />
        </g>
      );

    case 'backpack':
      return (
        <g id="accessory-layer">
          <rect x="230" y="248" width="46" height="58" rx="10" fill={color} />
          {/* Straps */}
          <path d="M236 248 L230 295 L238 296 L244 255 Z" fill={adjustColor(color, -20)} opacity="0.6" />
          <path d="M270 248 L276 295 L268 296 L262 255 Z" fill={adjustColor(color, -20)} opacity="0.6" />
          {/* Pocket */}
          <rect x="235" y="274" width="36" height="26" rx="6" fill={adjustColor(color, -25)} />
          <rect x="238" y="277" width="30" height="20" rx="4" fill={adjustColor(color, 15)} opacity="0.4" />
          {/* Zipper */}
          <line x1="244" y1="275" x2="262" y2="275" stroke="white" strokeWidth="2" opacity="0.6" />
        </g>
      );

    default:
      return null;
  }
}

function ShoesLayer({ shoes }) {
  if (!shoes || shoes === 'none') return null;
  const color = shoes.color || '#1A202C';
  const dark = adjustColor(color === '#FFFFFF' || color === '#F7FAFC' ? '#D0D0D0' : color, -35);
  const lx = 148, rx = 248;

  switch (shoes.style) {
    case 'sneakers':
      return (
        <g id="shoes-layer">
          {/* Left shoe */}
          <ellipse cx={lx} cy="398" rx="35" ry="14" fill={color} />
          <rect x={lx - 32} y="385" width="64" height="18" rx="8" fill={color} />
          <rect x={lx - 32} y="385" width="64" height="8" rx="4" fill="white" opacity="0.4" />
          <line x1={lx - 15} y1="388" x2={lx + 15} y2="388" stroke={dark} strokeWidth="1.5" opacity="0.5" />
          {/* Right shoe */}
          <ellipse cx={rx} cy="398" rx="35" ry="14" fill={color} />
          <rect x={rx - 32} y="385" width="64" height="18" rx="8" fill={color} />
          <rect x={rx - 32} y="385" width="64" height="8" rx="4" fill="white" opacity="0.4" />
          <line x1={rx - 15} y1="388" x2={rx + 15} y2="388" stroke={dark} strokeWidth="1.5" opacity="0.5" />
        </g>
      );

    case 'boots':
      return (
        <g id="shoes-layer">
          <rect x={lx - 28} y="368" width="56" height="42" rx="8" fill={color} />
          <ellipse cx={lx} cy="408" rx="32" ry="12" fill={dark} />
          <line x1={lx - 12} y1="377" x2={lx + 12} y2="377" stroke={adjustColor(color, 30)} strokeWidth="2" />
          <line x1={lx - 12} y1="386" x2={lx + 12} y2="386" stroke={adjustColor(color, 30)} strokeWidth="2" />
          <rect x={rx - 28} y="368" width="56" height="42" rx="8" fill={color} />
          <ellipse cx={rx} cy="408" rx="32" ry="12" fill={dark} />
          <line x1={rx - 12} y1="377" x2={rx + 12} y2="377" stroke={adjustColor(color, 30)} strokeWidth="2" />
          <line x1={rx - 12} y1="386" x2={rx + 12} y2="386" stroke={adjustColor(color, 30)} strokeWidth="2" />
        </g>
      );

    case 'heels':
      return (
        <g id="shoes-layer">
          <ellipse cx={lx - 5} cy="398" rx="30" ry="11" fill={color} />
          <rect x={lx - 30} y="385" width="52" height="15" rx="5" fill={color} />
          <line x1={lx + 22} y1="400" x2={lx + 26} y2="412" stroke={dark} strokeWidth="5" strokeLinecap="round" />
          <ellipse cx={rx - 5} cy="398" rx="30" ry="11" fill={color} />
          <rect x={rx - 30} y="385" width="52" height="15" rx="5" fill={color} />
          <line x1={rx + 22} y1="400" x2={rx + 26} y2="412" stroke={dark} strokeWidth="5" strokeLinecap="round" />
        </g>
      );

    case 'slippers':
      return (
        <g id="shoes-layer">
          <ellipse cx={lx} cy="398" rx="36" ry="15" fill={color} />
          <ellipse cx={lx - 10} cy="390" rx="20" ry="12" fill={adjustColor(color, -15)} />
          <circle cx={lx - 10} cy="388" r="7" fill={adjustColor(color, 20)} opacity="0.7" />
          <ellipse cx={rx} cy="398" rx="36" ry="15" fill={color} />
          <ellipse cx={rx - 10} cy="390" rx="20" ry="12" fill={adjustColor(color, -15)} />
          <circle cx={rx - 10} cy="388" r="7" fill={adjustColor(color, 20)} opacity="0.7" />
        </g>
      );

    case 'sandals':
      return (
        <g id="shoes-layer">
          <ellipse cx={lx} cy="400" rx="32" ry="10" fill={color} />
          <line x1={lx - 20} y1="392" x2={lx + 20} y2="395" stroke={color} strokeWidth="5" strokeLinecap="round" />
          <line x1={lx - 10} y1="385" x2={lx + 10} y2="388" stroke={color} strokeWidth="5" strokeLinecap="round" />
          <ellipse cx={rx} cy="400" rx="32" ry="10" fill={color} />
          <line x1={rx - 20} y1="392" x2={rx + 20} y2="395" stroke={color} strokeWidth="5" strokeLinecap="round" />
          <line x1={rx - 10} y1="385" x2={rx + 10} y2="388" stroke={color} strokeWidth="5" strokeLinecap="round" />
        </g>
      );

    default:
      return null;
  }
}

export default function BearSVG({ config, scale = 1, animated = false }) {
  const { BEAR_TYPES, CLOTHES, HATS, ACCESSORIES, SHOES } = require('../data/catalog');

  const bearType = BEAR_TYPES.find(b => b.id === config.bearType) || BEAR_TYPES[0];
  const bearColor = config.bearColor || bearType.baseColor;
  const clothes = CLOTHES.find(c => c.id === config.clothes);
  const hat = HATS.find(h => h.id === config.hat);
  const accessory = ACCESSORIES.find(a => a.id === config.accessories);
  const shoes = SHOES.find(s => s.id === config.shoes);

  const clothesWithColor = clothes ? { ...clothes, color: config.clothesColor || clothes.color } : null;

  return (
    <svg
      viewBox="0 0 400 430"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width: '100%', height: '100%', filter: 'drop-shadow(0 8px 24px rgba(0,0,0,0.15))' }}
    >
      <defs>
        <radialGradient id="bodyShine" cx="35%" cy="30%">
          <stop offset="0%" stopColor="white" stopOpacity="0.25" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* Shoes first (behind body) */}
      <ShoesLayer shoes={shoes} />

      {/* Bear body */}
      <BearBody color={bearColor} bearType={config.bearType} />

      {/* Clothes layer */}
      <ClothesLayer clothes={clothesWithColor} clothesColor={config.clothesColor} />

      {/* Accessories */}
      <AccessoryLayer accessory={accessory} />

      {/* Hat (on top) */}
      <HatLayer hat={hat} />

      {/* Shine overlay */}
      <ellipse cx="200" cy="175" rx="88" ry="88" fill="url(#bodyShine)" />
    </svg>
  );
}
