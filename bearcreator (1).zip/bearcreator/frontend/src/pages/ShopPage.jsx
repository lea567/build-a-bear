import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { BEAR_TYPES, CLOTHES, HATS, ACCESSORIES, SHOES } from '../data/catalog';

const ALL_PRODUCTS = [
  ...BEAR_TYPES.map(b => ({ ...b, category: 'Bears', emoji: '🐻', inStock: true })),
  ...CLOTHES.filter(c => c.id !== 'none').map(c => ({ ...c, category: 'Clothing', emoji: '👕', inStock: true })),
  ...HATS.filter(h => h.id !== 'none').map(h => ({ ...h, category: 'Hats', emoji: '🎩', inStock: true })),
  ...ACCESSORIES.filter(a => a.id !== 'none').map(a => ({ ...a, category: 'Accessories', emoji: '👓', inStock: true })),
  ...SHOES.filter(s => s.id !== 'none').map(s => ({ ...s, category: 'Shoes', emoji: '👟', inStock: true })),
];

const FILTERS = ['All', 'Bears', 'Clothing', 'Hats', 'Accessories', 'Shoes'];
const SORTS = ['Featured', 'Price: Low to High', 'Price: High to Low', 'Name A-Z'];

export default function ShopPage() {
  const navigate = useNavigate();
  const [activeFilter, setActiveFilter] = useState('All');
  const [sort, setSort] = useState('Featured');
  const [search, setSearch] = useState('');
  const [wishlist, setWishlist] = useState(new Set());

  const filtered = ALL_PRODUCTS
    .filter(p => activeFilter === 'All' || p.category === activeFilter)
    .filter(p => p.name.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      if (sort === 'Price: Low to High') return a.price - b.price;
      if (sort === 'Price: High to Low') return b.price - a.price;
      if (sort === 'Name A-Z') return a.name.localeCompare(b.name);
      return 0;
    });

  const toggleWishlist = (id) => {
    setWishlist(prev => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  const getCardColor = (item) => {
    if (item.color && item.color !== 'rainbow') return item.color;
    if (item.baseColor) return item.baseColor;
    return '#C4956A';
  };

  return (
    <div className="shop-page">
      {/* Header */}
      <div className="shop-header">
        <div className="container">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h1>Shop All The Stuff You Love</h1>
            <p>{ALL_PRODUCTS.length} products to make your bear uniquely yours</p>
          </motion.div>
        </div>
      </div>

      <div className="container">
        {/* Toolbar */}
        <div className="shop-toolbar">
          <div className="shop-filters">
            {FILTERS.map(f => (
              <motion.button key={f} className={`filter-btn ${activeFilter === f ? 'active' : ''}`}
                onClick={() => setActiveFilter(f)} whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }}>
                {f}
                {activeFilter === f && <motion.div className="filter-underline" layoutId="filterUnderline" />}
              </motion.button>
            ))}
          </div>
          <div className="shop-controls">
            <div className="search-box">
              <span>🔍</span>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search products..." />
            </div>
            <select className="sort-select" value={sort} onChange={e => setSort(e.target.value)}>
              {SORTS.map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>

        {/* Results count */}
        <div className="results-count">
          Showing <strong>{filtered.length}</strong> {activeFilter === 'All' ? 'products' : activeFilter.toLowerCase()}
        </div>

        {/* Grid */}
        <AnimatePresence mode="popLayout">
          <motion.div className="shop-grid" layout>
            {filtered.map((item, i) => (
              <motion.div key={item.id} className="shop-card" layout
                initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: i * 0.03 }} whileHover={{ y: -6 }}>
                <div className="shop-card-img" style={{ background: `${getCardColor(item)}22` }}>
                  <span className="shop-card-emoji" style={{ fontSize: item.category === 'Bears' ? '64px' : '48px' }}>
                    {item.category === 'Bears' ? '🐻' : item.emoji}
                  </span>
                  {item.color && item.color !== 'rainbow' && (
                    <div className="shop-color-dot" style={{ background: item.color }} />
                  )}
                  {item.color === 'rainbow' && (
                    <div className="shop-color-dot rainbow" />
                  )}
                  <button className={`wishlist-btn ${wishlist.has(item.id) ? 'active' : ''}`} onClick={() => toggleWishlist(item.id)}>
                    {wishlist.has(item.id) ? '❤️' : '🤍'}
                  </button>
                  <span className="shop-category-badge">{item.category}</span>
                </div>
                <div className="shop-card-body">
                  <h3>{item.name}</h3>
                  {item.description && <p className="shop-card-desc">{item.description}</p>}
                  <div className="shop-card-footer">
                    <span className="shop-price">${item.price}</span>
                    {item.category === 'Bears' ? (
                      <motion.button className="btn-build" onClick={() => navigate('/build')} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        Build →
                      </motion.button>
                    ) : (
                      <motion.button className="btn-add-shop" onClick={() => navigate('/build')} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        + Add
                      </motion.button>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        {filtered.length === 0 && (
          <div className="no-results">
            <span>🐾</span>
            <p>No products found for "{search}"</p>
            <button onClick={() => { setSearch(''); setActiveFilter('All'); }}>Clear filters</button>
          </div>
        )}
      </div>
    </div>
  );
}
