import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';

const FEATURED = [
  { id: 1, name: 'Classic Teddy', price: 29, color: '#C4956A', emoji: '🐻', tag: 'Bestseller' },
  { id: 2, name: 'Panda Pal', price: 32, color: '#2d2d2d', emoji: '🐼', tag: 'New' },
  { id: 3, name: 'Polar Puff', price: 35, color: '#e8e4dc', emoji: '🐻‍❄️', tag: 'Fan Fave' },
  { id: 4, name: 'Honey Bear', price: 28, color: '#D4A853', emoji: '🧸', tag: 'Sale' },
];

const STEPS = [
  { step: '01', title: 'Choose Your Bear', desc: 'Pick from 6 unique bear types — classic, panda, polar and more.', emoji: '🐾' },
  { step: '02', title: 'Stuff It With Love', desc: 'Your bear gets filled and you place a heart inside with a wish.', emoji: '❤️' },
  { step: '03', title: 'Dress & Accessorize', desc: 'Pick outfits, hats, shoes and accessories from hundreds of options.', emoji: '👗' },
  { step: '04', title: 'Record a Message', desc: 'Give your bear a voice — record a personal audio message.', emoji: '🎤' },
  { step: '05', title: 'Name Your Bear', desc: 'Give your best friend a name and make it truly yours.', emoji: '✏️' },
  { step: '06', title: 'Take It Home', desc: 'Your bear ships in its very own Cub Condo carrying box.', emoji: '🏠' },
];

const CATEGORIES = [
  { label: 'Bears & Animals', emoji: '🐻', color: '#f9e4c8', count: '30+' },
  { label: 'Clothing', emoji: '👕', color: '#d4e8f9', count: '120+' },
  { label: 'Accessories', emoji: '👓', color: '#f9d4e8', count: '80+' },
  { label: 'Hats', emoji: '🎩', color: '#d4f9e4', count: '40+' },
  { label: 'Shoes', emoji: '👟', color: '#e8d4f9', count: '35+' },
  { label: 'Gift Sets', emoji: '🎁', color: '#f9f4d4', count: '20+' },
];

export default function HomePage() {
  const navigate = useNavigate();
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: heroRef });
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 120]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.6], [1, 0]);
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  const testimonials = [
    { text: "My daughter cried happy tears when she got her custom bear. Nothing beats watching her name it and put the heart in!", author: "Sarah M.", loc: "New York" },
    { text: "Ordered three for my grandchildren. The quality is incredible and the voice message feature made Christmas so magical.", author: "Robert K.", loc: "Texas" },
    { text: "Best gift I've ever given. My best friend got the bear with a recorded message of our inside jokes — she still carries it around.", author: "Priya L.", loc: "California" },
  ];

  useEffect(() => {
    const t = setInterval(() => setActiveTestimonial(p => (p + 1) % testimonials.length), 4000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="homepage">

      {/* ── Hero ── */}
      <section className="hero" ref={heroRef}>
        <motion.div className="hero-bg-blobs">
          <div className="blob blob-1" />
          <div className="blob blob-2" />
          <div className="blob blob-3" />
        </motion.div>
        <motion.div className="hero-content" style={{ y: heroY, opacity: heroOpacity }}>
          <motion.div className="hero-badge" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            ✨ The Stuff You Love
          </motion.div>
          <motion.h1 className="hero-title" initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35, duration: 0.7 }}>
            Make Your<br /><span className="hero-title-accent">Perfect Bear</span><br />Come to Life
          </motion.h1>
          <motion.p className="hero-sub" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
            Build, dress, name, and love a one-of-a-kind furry friend.<br />Every bear is uniquely yours — stuffed with imagination and heart.
          </motion.p>
          <motion.div className="hero-ctas" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.65 }}>
            <motion.button className="btn-hero-primary" onClick={() => navigate('/build')} whileHover={{ scale: 1.04, y: -2 }} whileTap={{ scale: 0.97 }}>
              🐾 Start Building
            </motion.button>
            <motion.button className="btn-hero-secondary" onClick={() => navigate('/shop')} whileHover={{ scale: 1.04, y: -2 }} whileTap={{ scale: 0.97 }}>
              Shop All Bears
            </motion.button>
          </motion.div>
          <motion.div className="hero-stats" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }}>
            {[['500+', 'Locations'], ['25M+', 'Bears Made'], ['4.9★', 'Rating'], ['Free', 'Shipping $50+']].map(([val, lbl]) => (
              <div key={lbl} className="stat">
                <strong>{val}</strong>
                <span>{lbl}</span>
              </div>
            ))}
          </motion.div>
        </motion.div>
        <motion.div className="hero-bears" initial={{ opacity: 0, x: 60 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4, duration: 0.8 }}>
          {['🐻', '🐼', '🐻‍❄️', '🧸'].map((bear, i) => (
            <motion.div key={i} className="floating-bear" style={{ '--delay': `${i * 0.8}s`, '--size': `${90 - i * 10}px` }}
              animate={{ y: [0, -12, 0] }} transition={{ duration: 2.5 + i * 0.4, repeat: Infinity, delay: i * 0.6 }}>
              {bear}
            </motion.div>
          ))}
        </motion.div>
        <div className="hero-wave">
          <svg viewBox="0 0 1440 80" preserveAspectRatio="none"><path d="M0,40 C360,80 1080,0 1440,40 L1440,80 L0,80 Z" fill="#fff9f4" /></svg>
        </div>
      </section>

      {/* ── Categories ── */}
      <section className="section categories-section">
        <div className="container">
          <motion.div className="section-header" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2>Shop by Category</h2>
            <p>Everything your bear could ever need</p>
          </motion.div>
          <div className="categories-grid">
            {CATEGORIES.map((cat, i) => (
              <motion.div key={cat.label} className="category-card" style={{ '--cat-bg': cat.color }}
                initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                whileHover={{ y: -6, scale: 1.03 }} onClick={() => navigate('/shop')}>
                <span className="cat-emoji">{cat.emoji}</span>
                <strong>{cat.label}</strong>
                <span className="cat-count">{cat.count} items</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Featured Bears ── */}
      <section className="section featured-section">
        <div className="container">
          <motion.div className="section-header" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2>Most Loved Bears</h2>
            <p>Start with one of our fan favorites, then make it yours</p>
          </motion.div>
          <div className="featured-grid">
            {FEATURED.map((bear, i) => (
              <motion.div key={bear.id} className="bear-card"
                initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                whileHover={{ y: -8 }}>
                <div className="bear-card-img" style={{ background: `${bear.color}22` }}>
                  <span className="bear-card-emoji">{bear.emoji}</span>
                  <span className="bear-card-tag">{bear.tag}</span>
                </div>
                <div className="bear-card-body">
                  <h3>{bear.name}</h3>
                  <div className="bear-card-footer">
                    <span className="bear-card-price">From ${bear.price}</span>
                    <motion.button className="btn-customize" onClick={() => navigate('/build')} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      Customize →
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          <div className="section-cta">
            <motion.button className="btn-outline" onClick={() => navigate('/shop')} whileHover={{ scale: 1.03 }}>
              View All Bears
            </motion.button>
          </div>
        </div>
      </section>

      {/* ── How It Works ── */}
      <section className="section how-section">
        <div className="how-bg" />
        <div className="container">
          <motion.div className="section-header light" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2>How It Works</h2>
            <p>Six magical steps to your perfect companion</p>
          </motion.div>
          <div className="steps-grid">
            {STEPS.map((s, i) => (
              <motion.div key={s.step} className="step-card"
                initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                <div className="step-number">{s.step}</div>
                <div className="step-emoji">{s.emoji}</div>
                <h4>{s.title}</h4>
                <p>{s.desc}</p>
              </motion.div>
            ))}
          </div>
          <div className="section-cta">
            <motion.button className="btn-hero-primary" onClick={() => navigate('/build')} whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
              Start Your Build →
            </motion.button>
          </div>
        </div>
      </section>

      {/* ── Promo Banner ── */}
      <section className="promo-banner">
        <div className="container">
          <motion.div className="promo-inner" initial={{ opacity: 0, scale: 0.97 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}>
            <div className="promo-text">
              <span className="promo-tag">Limited Time</span>
              <h2>Free Shipping on Orders Over $50</h2>
              <p>Plus free gift wrapping on all orders this week. No code needed.</p>
              <motion.button className="btn-hero-primary" onClick={() => navigate('/build')} whileHover={{ scale: 1.04 }}>
                Shop Now — Free Shipping
              </motion.button>
            </div>
            <div className="promo-bears">
              {['🎁', '🐻', '🎀', '🧸', '💝'].map((e, i) => (
                <motion.span key={i} className="promo-bear-emoji"
                  animate={{ y: [0, -8, 0], rotate: [-5, 5, -5] }}
                  transition={{ duration: 2 + i * 0.3, repeat: Infinity, delay: i * 0.4 }}>
                  {e}
                </motion.span>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── Testimonials ── */}
      <section className="section testimonials-section">
        <div className="container">
          <motion.div className="section-header" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2>Made with Love ❤️</h2>
            <p>What our customers say</p>
          </motion.div>
          <div className="testimonials-wrapper">
            <AnimatePresence mode="wait">
              <motion.div key={activeTestimonial} className="testimonial-card"
                initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} transition={{ duration: 0.4 }}>
                <div className="testimonial-stars">★★★★★</div>
                <blockquote>"{testimonials[activeTestimonial].text}"</blockquote>
                <cite>— {testimonials[activeTestimonial].author}, {testimonials[activeTestimonial].loc}</cite>
              </motion.div>
            </AnimatePresence>
            <div className="testimonial-dots">
              {testimonials.map((_, i) => (
                <button key={i} className={`dot ${i === activeTestimonial ? 'active' : ''}`} onClick={() => setActiveTestimonial(i)} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Newsletter ── */}
      <section className="newsletter-section">
        <div className="container">
          <motion.div className="newsletter-inner" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h3>🐾 Join the Bear Family</h3>
            <p>Get exclusive deals, new arrivals, and bear-building tips.</p>
            <div className="newsletter-form">
              <input type="email" placeholder="Enter your email..." className="newsletter-input" />
              <motion.button className="btn-newsletter" whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                Subscribe
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
