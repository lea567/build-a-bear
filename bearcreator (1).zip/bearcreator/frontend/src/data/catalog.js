// Bear catalog - all customizable items with SVG-based rendering
export const BEAR_TYPES = [
  { id: 'classic', name: 'Classic Teddy', baseColor: '#C4956A', price: 25, description: 'The timeless companion' },
  { id: 'fluffy', name: 'Fluffy Cloud', baseColor: '#E8D5C4', price: 30, description: 'Extra soft & cuddly' },
  { id: 'dark', name: 'Cocoa Bear', baseColor: '#6B4226', price: 25, description: 'Rich dark chocolate fur' },
  { id: 'polar', name: 'Polar Puff', baseColor: '#F0EEE9', price: 35, description: 'Arctic white fur' },
  { id: 'panda', name: 'Panda Pal', baseColor: '#FFFFFF', price: 35, description: 'Black & white magic' },
  { id: 'honey', name: 'Honey Bear', baseColor: '#D4A853', price: 28, description: 'Golden honey hue' },
];

export const CLOTHES = [
  { id: 'none', name: 'No Clothes', price: 0, category: 'clothes', color: null },
  { id: 'tshirt_red', name: 'Red Tee', price: 8, category: 'clothes', color: '#E53E3E', style: 'tshirt' },
  { id: 'tshirt_blue', name: 'Ocean Tee', price: 8, category: 'clothes', color: '#3182CE', style: 'tshirt' },
  { id: 'tshirt_green', name: 'Forest Tee', price: 8, category: 'clothes', color: '#38A169', style: 'tshirt' },
  { id: 'tshirt_pink', name: 'Blossom Tee', price: 8, category: 'clothes', color: '#ED64A6', style: 'tshirt' },
  { id: 'tshirt_purple', name: 'Lavender Tee', price: 8, category: 'clothes', color: '#805AD5', style: 'tshirt' },
  { id: 'dress_pink', name: 'Princess Dress', price: 14, category: 'clothes', color: '#FBB6CE', style: 'dress' },
  { id: 'dress_blue', name: 'Ocean Dress', price: 14, category: 'clothes', color: '#90CDF4', style: 'dress' },
  { id: 'dress_yellow', name: 'Sunshine Dress', price: 14, category: 'clothes', color: '#FAF089', style: 'dress' },
  { id: 'overalls_blue', name: 'Denim Overalls', price: 12, category: 'clothes', color: '#4299E1', style: 'overalls' },
  { id: 'overalls_red', name: 'Red Overalls', price: 12, category: 'clothes', color: '#FC8181', style: 'overalls' },
  { id: 'hoodie_gray', name: 'Cozy Hoodie', price: 15, category: 'clothes', color: '#A0AEC0', style: 'hoodie' },
  { id: 'hoodie_navy', name: 'Navy Hoodie', price: 15, category: 'clothes', color: '#2C5282', style: 'hoodie' },
  { id: 'suit_black', name: 'Dapper Suit', price: 20, category: 'clothes', color: '#2D3748', style: 'suit' },
];

export const HATS = [
  { id: 'none', name: 'No Hat', price: 0, category: 'hats' },
  { id: 'party', name: 'Party Hat', price: 5, category: 'hats', color: '#F6AD55', style: 'party' },
  { id: 'tophat', name: 'Top Hat', price: 10, category: 'hats', color: '#1A202C', style: 'tophat' },
  { id: 'beanie_red', name: 'Red Beanie', price: 7, category: 'hats', color: '#E53E3E', style: 'beanie' },
  { id: 'beanie_blue', name: 'Blue Beanie', price: 7, category: 'hats', color: '#3182CE', style: 'beanie' },
  { id: 'bow_pink', name: 'Pink Bow', price: 6, category: 'hats', color: '#FBB6CE', style: 'bow' },
  { id: 'bow_red', name: 'Red Bow', price: 6, category: 'hats', color: '#FC8181', style: 'bow' },
  { id: 'cap_baseball', name: 'Baseball Cap', price: 8, category: 'hats', color: '#2C5282', style: 'cap' },
  { id: 'crown', name: 'Royal Crown', price: 15, category: 'hats', color: '#F6E05E', style: 'crown' },
  { id: 'santa', name: 'Santa Hat', price: 9, category: 'hats', color: '#E53E3E', style: 'santa' },
  { id: 'witch', name: 'Witch Hat', price: 9, category: 'hats', color: '#1A202C', style: 'witch' },
  { id: 'flower_crown', name: 'Flower Crown', price: 12, category: 'hats', color: '#F687B3', style: 'flower_crown' },
];

export const ACCESSORIES = [
  { id: 'none', name: 'None', price: 0, category: 'accessories' },
  { id: 'glasses_round', name: 'Round Glasses', price: 7, category: 'accessories', style: 'glasses_round', color: '#4A5568' },
  { id: 'glasses_square', name: 'Square Glasses', price: 7, category: 'accessories', style: 'glasses_square', color: '#1A202C' },
  { id: 'glasses_heart', name: 'Heart Glasses', price: 9, category: 'accessories', style: 'glasses_heart', color: '#E53E3E' },
  { id: 'scarf_red', name: 'Red Scarf', price: 8, category: 'accessories', style: 'scarf', color: '#E53E3E' },
  { id: 'scarf_blue', name: 'Blue Scarf', price: 8, category: 'accessories', style: 'scarf', color: '#3182CE' },
  { id: 'scarf_rainbow', name: 'Rainbow Scarf', price: 10, category: 'accessories', style: 'scarf', color: 'rainbow' },
  { id: 'tie_bow', name: 'Bow Tie', price: 6, category: 'accessories', style: 'bowtie', color: '#E53E3E' },
  { id: 'tie_neck', name: 'Neck Tie', price: 6, category: 'accessories', style: 'necktie', color: '#2C5282' },
  { id: 'necklace', name: 'Pearl Necklace', price: 12, category: 'accessories', style: 'necklace', color: '#F0E68C' },
  { id: 'backpack', name: 'Mini Backpack', price: 14, category: 'accessories', style: 'backpack', color: '#4299E1' },
];

export const SHOES = [
  { id: 'none', name: 'No Shoes', price: 0, category: 'shoes' },
  { id: 'sneakers_white', name: 'White Sneakers', price: 10, category: 'shoes', color: '#F7FAFC', style: 'sneakers' },
  { id: 'sneakers_red', name: 'Red Sneakers', price: 10, category: 'shoes', color: '#E53E3E', style: 'sneakers' },
  { id: 'boots_brown', name: 'Brown Boots', price: 12, category: 'shoes', color: '#744210', style: 'boots' },
  { id: 'boots_black', name: 'Black Boots', price: 12, category: 'shoes', color: '#1A202C', style: 'boots' },
  { id: 'heels_pink', name: 'Pink Heels', price: 14, category: 'shoes', color: '#FBB6CE', style: 'heels' },
  { id: 'slippers', name: 'Cozy Slippers', price: 8, category: 'shoes', color: '#FEB2B2', style: 'slippers' },
  { id: 'sandals', name: 'Summer Sandals', price: 9, category: 'shoes', color: '#D69E2E', style: 'sandals' },
];

export const DEFAULT_CONFIG = {
  bearType: 'classic',
  bearColor: '#C4956A',
  clothes: 'none',
  clothesColor: null,
  hat: 'none',
  accessories: 'none',
  shoes: 'none',
  name: 'My Bear',
};

export function calculatePrice(config) {
  const bear = BEAR_TYPES.find(b => b.id === config.bearType) || BEAR_TYPES[0];
  const clothes = CLOTHES.find(c => c.id === config.clothes) || CLOTHES[0];
  const hat = HATS.find(h => h.id === config.hat) || HATS[0];
  const acc = ACCESSORIES.find(a => a.id === config.accessories) || ACCESSORIES[0];
  const shoe = SHOES.find(s => s.id === config.shoes) || SHOES[0];
  return bear.price + clothes.price + hat.price + acc.price + shoe.price;
}
