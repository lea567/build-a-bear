import React, { useState, useRef, useCallback } from 'react';
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence, useSpring, useMotionValue } from 'framer-motion';
import { Toaster, toast } from 'react-hot-toast';
import { HexColorPicker } from 'react-colorful';
import html2canvas from 'html2canvas';
import { BearProvider, useBear } from './context/BearContext';
import BearSVG from './components/BearSVG';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import ShopPage from './pages/ShopPage';
import CartPage from './pages/CartPage';
import { BEAR_TYPES, CLOTHES, HATS, ACCESSORIES, SHOES } from './data/catalog';
import { saveBear, getBears, uploadAudio, uploadImage, addToCart } from './utils/api';
import { useVoiceRecorder } from './hooks/useVoiceRecorder';
import './App.css';

const Icon = ({ name, size = 20 }) => {
  const icons = {
    bear:    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14H8v-2h2v2zm0-4H8v-2h2v2zm0-4H8V6h2v2zm6 8h-2v-2h2v2zm0-4h-2v-2h2v2zm0-4h-2V6h2v2z"/>,
    shirt:   <path d="M16 2v2l-4 4-4-4V2L3 5v5l3-2v10h12V8l3 2V5z"/>,
    hat:     <path d="M5 16h14v2H5zm11-7.34V6c0-1.1-.9-2-2-2H10c-1.1 0-2 .9-2 2v2.66C6.31 9.21 5 10.96 5 13h14c0-2.04-1.31-3.79-3-4.34z"/>,
    glasses: <path d="M20 6h-1V4h-2v2H7V4H5v2H4c-1.1 0-2 .9-2 2v2c0 2.21 1.79 4 4 4 1.31 0 2.46-.64 3.2-1.62L12 14l2.8-1.62C15.54 13.36 16.69 14 18 14c2.21 0 4-1.79 4-4V8c0-1.1-.9-2-2-2zM6 12c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm12 0c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/>,
    shoe:    <path d="M20 18c1.1 0 2-.9 2-2v-3l-4-4V5c0-1.1-.9-2-2-2s-2 .9-2 2v2H4C2.9 7 2 7.9 2 9v5h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3z"/>,
    mic:     <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm-1-9c0-.55.45-1 1-1s1 .45 1 1v6c0 .55-.45 1-1 1s-1-.45-1-1V5zm6 6c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/>,
    stop:    <path d="M6 6h12v12H6z"/>,
    play:    <path d="M8 5v14l11-7z"/>,
    save:    <path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/>,
    share:   <path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/>,
    cart:    <path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96C5 16.1 6.1 17 7 17h11v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63H19c.75 0 1.41-.41 1.75-1.03l3.58-6.49A1 1 0 0023.25 2H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/>,
    close:   <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>,
    palette: <path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12zm3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5S18.33 12 17.5 12z"/>,
    trash:   <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>,
    check:   <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>,
    history: <path d="M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/>,
    download:<path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">{icons[name]}</svg>;
};

const TABS = [
  { id: 'bearType', label: 'Bear', icon: 'bear' },
  { id: 'clothes', label: 'Clothes', icon: 'shirt' },
  { id: 'hats', label: 'Hats', icon: 'hat' },
  { id: 'accessories', label: 'Extras', icon: 'glasses' },
  { id: 'shoes', label: 'Shoes', icon: 'shoe' },
];

function ColorSwatch({ color, selected, onClick }) {
  return (
    <motion.button className={`color-swatch ${selected ? 'selected' : ''}`} style={{ background: color }}
      onClick={onClick} whileHover={{ scale: 1.15 }} whileTap={{ scale: 0.9 }}>
      {selected && <span className="swatch-check"><Icon name="check" size={12} /></span>}
    </motion.button>
  );
}

function ItemCard({ item, selected, onClick }) {
  return (
    <motion.button className={`item-card ${selected ? 'selected' : ''}`} onClick={onClick}
      whileHover={{ y: -4, scale: 1.02 }} whileTap={{ scale: 0.96 }} layout>
      {item.color && item.color !== 'rainbow' && <div className="item-color-dot" style={{ background: item.color }} />}
      {item.color === 'rainbow' && <div className="item-color-dot rainbow-dot" />}
      <span className="item-name">{item.name}</span>
      {item.price > 0 && <span className="item-price">${item.price}</span>}
      {selected && <div className="item-selected-ring" />}
    </motion.button>
  );
}

function VoiceRecorderPanel({ onRecordingComplete }) {
  const { isRecording, formattedDuration, audioBlob, audioUrl, volume, error, startRecording, stopRecording, clearRecording } = useVoiceRecorder();
  const audioRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [uploading, setUploading] = useState(false);
  const bars = Array.from({ length: 28 }, (_, i) => i);

  const handleUpload = async () => {
    if (!audioBlob) return;
    setUploading(true);
    try {
      const result = await uploadAudio(audioBlob);
      onRecordingComplete(result.filename);
      toast.success('Voice saved!');
    } catch { toast.error('Failed to save recording'); }
    finally { setUploading(false); }
  };

  return (
    <div className="voice-panel">
      <div className="voice-header"><Icon name="mic" size={18} /><span>Voice Message</span><span className="voice-subtitle">Add a personal message</span></div>
      {error && <div className="voice-error">{error}</div>}
      <div className="waveform-container">
        {bars.map((i) => {
          const h = isRecording ? 0.2 + Math.abs(Math.sin((Date.now() / 150 + i) * 0.8)) * volume * 0.8 : audioBlob ? 0.3 + Math.abs(Math.sin(i * 0.7)) * 0.4 : 0.15;
          return <motion.div key={i} className="waveform-bar" animate={{ scaleY: h }} transition={{ duration: 0.1 }} />;
        })}
      </div>
      <div className={`timer ${isRecording ? 'recording' : ''}`}>
        {isRecording && <span className="rec-dot" />}<span>{formattedDuration}</span>
      </div>
      <div className="voice-controls">
        {!isRecording && !audioBlob && <motion.button className="btn-record" onClick={startRecording} whileHover={{ scale: 1.05 }}><Icon name="mic" size={18} /> Record</motion.button>}
        {isRecording && <motion.button className="btn-stop" onClick={stopRecording} whileHover={{ scale: 1.05 }}><Icon name="stop" size={18} /> Stop</motion.button>}
        {audioBlob && !isRecording && (
          <>
            <audio ref={audioRef} src={audioUrl} onPlay={() => setIsPlaying(true)} onPause={() => setIsPlaying(false)} onEnded={() => setIsPlaying(false)} />
            <motion.button className="btn-play" onClick={() => isPlaying ? audioRef.current.pause() : audioRef.current.play()} whileHover={{ scale: 1.05 }}>
              <Icon name={isPlaying ? 'stop' : 'play'} size={16} />{isPlaying ? 'Pause' : 'Preview'}
            </motion.button>
            <motion.button className="btn-upload" onClick={handleUpload} disabled={uploading} whileHover={{ scale: 1.05 }}>
              {uploading ? '...' : <><Icon name="save" size={16} /> Save</>}
            </motion.button>
            <motion.button className="btn-clear" onClick={clearRecording} whileHover={{ scale: 1.05 }}><Icon name="trash" size={16} /></motion.button>
          </>
        )}
      </div>
    </div>
  );
}

function SavedBearsModal({ onClose, onLoad }) {
  const { savedBears, setSavedBears } = useBear();
  const [loading, setLoading] = useState(false);
  React.useEffect(() => {
    setLoading(true);
    getBears().then(res => setSavedBears(res.bears || [])).catch(() => setSavedBears([])).finally(() => setLoading(false));
  }, []);
  return (
    <motion.div className="modal-overlay" onClick={onClose} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <motion.div className="modal-saved" onClick={e => e.stopPropagation()} initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}>
        <div className="modal-header"><h2>🐻 Saved Bears</h2><button className="btn-icon" onClick={onClose}><Icon name="close" size={20} /></button></div>
        {loading ? <div className="loading-spinner">Loading...</div> : savedBears.length === 0 ? (
          <div className="cart-empty"><span style={{ fontSize: 60 }}>🐾</span><p>No saved bears yet!</p></div>
        ) : (
          <div className="saved-grid">
            {savedBears.map(bear => (
              <motion.div key={bear.id} className="saved-bear-card" whileHover={{ y: -4 }}>
                <div className="saved-bear-preview" style={{ background: `${bear.bear_color || '#C4956A'}22` }}><span style={{ fontSize: 48 }}>🐻</span></div>
                <div className="saved-bear-info"><strong>{bear.name}</strong><span>${bear.total_price?.toFixed(2)}</span></div>
                <button className="btn-load" onClick={() => { onLoad(bear); onClose(); }}>Load</button>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}

function BearCustomizer() {
  const { config, totalPrice, activeTab, cart, setConfig, setBearColor, setClothesColor, setActiveTab, loadBear, reset, setCart, setSavedAudio, savedAudioFilename } = useBear();
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showClothesColor, setShowClothesColor] = useState(false);
  const [showSaved, setShowSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const bearPreviewRef = useRef(null);
  const rotateX = useSpring(useMotionValue(0), { stiffness: 100, damping: 20 });
  const rotateY = useSpring(useMotionValue(0), { stiffness: 100, damping: 20 });

  const handleMouseMove = useCallback((e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    rotateX.set(((e.clientY - rect.top - rect.height / 2) / rect.height) * -12);
    rotateY.set(((e.clientX - rect.left - rect.width / 2) / rect.width) * 12);
  }, []);
  const handleMouseLeave = useCallback(() => { rotateX.set(0); rotateY.set(0); }, []);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await saveBear({ name: config.name || 'My Bear', bearType: config.bearType, bearColor: config.bearColor, config, audioFile: savedAudioFilename, totalPrice });
      toast.success(`🐻 "${config.name}" saved!`);
    } catch { toast.error('Failed to save'); }
    finally { setIsSaving(false); }
  };

  const handleAddToCart = async () => {
    setIsSaving(true);
    try {
      const saveResult = await saveBear({ name: config.name || 'My Bear', bearType: config.bearType, bearColor: config.bearColor, config, audioFile: savedAudioFilename, totalPrice });
      await addToCart(saveResult.bear.id);
      setCart([...cart, { ...saveResult.bear, total_price: totalPrice, quantity: 1 }]);
      toast.success('Added to cart! 🛒');
    } catch { toast.error('Could not add to cart'); }
    finally { setIsSaving(false); }
  };

  const handleExport = async () => {
    if (!bearPreviewRef.current) return;
    try {
      const canvas = await html2canvas(bearPreviewRef.current, { backgroundColor: null, scale: 3 });
      const a = document.createElement('a');
      a.href = canvas.toDataURL('image/png');
      a.download = `${config.name || 'my-bear'}.png`;
      a.click();
      toast.success('Exported! 📸');
    } catch { toast.error('Export failed'); }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'bearType': return (
        <div className="tab-content">
          <div className="section-title">Bear Type</div>
          <div className="items-grid">{BEAR_TYPES.map(bear => <ItemCard key={bear.id} item={{ ...bear, color: bear.baseColor }} selected={config.bearType === bear.id} onClick={() => setConfig({ bearType: bear.id, bearColor: bear.baseColor })} />)}</div>
          <div className="section-title">Fur Color
            <button className="btn-color-picker" onClick={() => setShowColorPicker(!showColorPicker)}>
              <div className="current-color" style={{ background: config.bearColor }} /><Icon name="palette" size={14} />
            </button>
          </div>
          <AnimatePresence>
            {showColorPicker && (
              <motion.div className="color-picker-wrap" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <HexColorPicker color={config.bearColor} onChange={setBearColor} />
                <div className="color-presets">
                  {['#C4956A','#D4A853','#6B4226','#F0EEE9','#FFFFFF','#8B6F47','#E8D5C4','#B5835A'].map(c => <ColorSwatch key={c} color={c} selected={config.bearColor === c} onClick={() => setBearColor(c)} />)}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      );
      case 'clothes': return (
        <div className="tab-content">
          <div className="section-title">Outfit</div>
          <div className="items-grid">{CLOTHES.map(item => <ItemCard key={item.id} item={item} selected={config.clothes === item.id} onClick={() => setConfig({ clothes: item.id })} />)}</div>
          {config.clothes !== 'none' && (
            <>
              <div className="section-title">Outfit Color
                <button className="btn-color-picker" onClick={() => setShowClothesColor(!showClothesColor)}>
                  <div className="current-color" style={{ background: config.clothesColor || CLOTHES.find(c => c.id === config.clothes)?.color || '#888' }} /><Icon name="palette" size={14} />
                </button>
              </div>
              <AnimatePresence>
                {showClothesColor && (
                  <motion.div className="color-picker-wrap" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                    <HexColorPicker color={config.clothesColor || '#E53E3E'} onChange={setClothesColor} />
                  </motion.div>
                )}
              </AnimatePresence>
            </>
          )}
        </div>
      );
      case 'hats': return <div className="tab-content"><div className="section-title">Headwear</div><div className="items-grid">{HATS.map(item => <ItemCard key={item.id} item={item} selected={config.hat === item.id} onClick={() => setConfig({ hat: item.id })} />)}</div></div>;
      case 'accessories': return <div className="tab-content"><div className="section-title">Accessories</div><div className="items-grid">{ACCESSORIES.map(item => <ItemCard key={item.id} item={item} selected={config.accessories === item.id} onClick={() => setConfig({ accessories: item.id })} />)}</div></div>;
      case 'shoes': return <div className="tab-content"><div className="section-title">Footwear</div><div className="items-grid">{SHOES.map(item => <ItemCard key={item.id} item={item} selected={config.shoes === item.id} onClick={() => setConfig({ shoes: item.id })} />)}</div></div>;
      default: return null;
    }
  };

  return (
    <div className="app-root">
      <Toaster position="top-right" toastOptions={{ style: { background: '#3d1a06', color: '#fff', border: '1px solid rgba(232,82,26,0.3)' } }} />
      <div className="app-main">
        <aside className="customizer-panel">
          <div className="tab-bar">
            {TABS.map(tab => (
              <motion.button key={tab.id} className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`} onClick={() => setActiveTab(tab.id)} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Icon name={tab.icon} size={18} /><span>{tab.label}</span>
                {activeTab === tab.id && <motion.div className="tab-indicator" layoutId="tabIndicator" />}
              </motion.button>
            ))}
          </div>
          <div className="panel-scroll">
            <AnimatePresence mode="wait">
              <motion.div key={activeTab} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} transition={{ duration: 0.2 }}>
                {renderTabContent()}
              </motion.div>
            </AnimatePresence>
          </div>
        </aside>
        <main className="preview-area">
          <div className="bear-name-wrap">
            <input className="bear-name-input" value={config.name} onChange={e => setConfig({ name: e.target.value })} placeholder="Name your bear..." maxLength={30} />
          </div>
          <motion.div className="bear-stage" onMouseMove={handleMouseMove} onMouseLeave={handleMouseLeave} style={{ perspective: 600 }}>
            <motion.div className="bear-3d-wrapper" style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }}>
              <div className="bear-glow" style={{ background: `radial-gradient(ellipse at 50% 80%, ${config.bearColor}55 0%, transparent 70%)` }} />
              <div ref={bearPreviewRef} className="bear-preview"><BearSVG config={config} /></div>
            </motion.div>
          </motion.div>
          <div className="preview-controls">
            <motion.button className="btn-ctrl" onClick={handleExport} title="Export" whileHover={{ scale: 1.1 }}><Icon name="download" size={16} /></motion.button>
            <motion.button className="btn-ctrl" onClick={() => { navigator.clipboard?.writeText(`My bear: ${config.name}`); toast.success('Copied!'); }} title="Share" whileHover={{ scale: 1.1 }}><Icon name="share" size={16} /></motion.button>
            <motion.button className="btn-ctrl" onClick={() => setShowSaved(true)} title="Saved" whileHover={{ scale: 1.1 }}><Icon name="history" size={16} /></motion.button>
            <motion.button className="btn-ctrl danger" onClick={reset} title="Reset" whileHover={{ scale: 1.1 }}><Icon name="trash" size={16} /></motion.button>
          </div>
          <div className="price-tag">
            <span className="price-label">Total</span>
            <motion.span className="price-value" key={totalPrice} initial={{ scale: 1.3 }} animate={{ scale: 1 }} transition={{ duration: 0.3 }}>${totalPrice.toFixed(2)}</motion.span>
          </div>
          <div className="action-buttons">
            <motion.button className="btn-save" onClick={handleSave} disabled={isSaving} whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
              <Icon name="save" size={18} />{isSaving ? 'Saving...' : 'Save Bear'}
            </motion.button>
            <motion.button className="btn-cart-add" onClick={handleAddToCart} disabled={isSaving} whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
              <Icon name="cart" size={18} />Add to Cart
            </motion.button>
          </div>
        </main>
        <aside className="right-panel">
          <VoiceRecorderPanel onRecordingComplete={(filename) => setSavedAudio(filename)} />
          <div className="price-breakdown">
            <h4>Price Breakdown</h4>
            {[{ label: 'Bear', id: config.bearType, list: BEAR_TYPES }, { label: 'Clothes', id: config.clothes, list: CLOTHES }, { label: 'Hat', id: config.hat, list: HATS }, { label: 'Accessories', id: config.accessories, list: ACCESSORIES }, { label: 'Shoes', id: config.shoes, list: SHOES }].map(({ label, id, list }) => {
              const item = list.find(i => i.id === id);
              if (!item || item.price === 0) return null;
              return <div key={label} className="breakdown-row"><span>{label}: {item.name}</span><span>${item.price}</span></div>;
            })}
            <div className="breakdown-total"><span>Total</span><span>${totalPrice.toFixed(2)}</span></div>
          </div>
        </aside>
      </div>
      <AnimatePresence>
        {showSaved && <SavedBearsModal onClose={() => setShowSaved(false)} onLoad={(bear) => { loadBear(bear.config || bear); toast.success('Bear loaded!'); }} />}
      </AnimatePresence>
    </div>
  );
}

function BuildPage() {
  return (
    <div className="build-page">
      <div className="build-page-header">
        <h1>🐾 Build Your Bear</h1>
        <p>Choose every detail — then add a voice message to make it one of a kind</p>
      </div>
      <BearCustomizer />
    </div>
  );
}

function AppLayout() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/shop" element={<ShopPage />} />
        <Route path="/build" element={<BuildPage />} />
        <Route path="/cart" element={<CartPage />} />
      </Routes>
      <Footer />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <BearProvider>
        <AppLayout />
      </BearProvider>
    </BrowserRouter>
  );
}
